package com.example.service.impl;

import com.example.model.Dentista;
import com.example.model.DentistaDTO;
import com.example.repository.IDentistaRepository;
import com.example.service.DentistaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DentistaServiceImpl implements DentistaService {

    @Autowired
    IDentistaRepository dentistaRepository;

    @Autowired
    ObjectMapper mapper;

    private void saveDentista(DentistaDTO dentistaDTO){
        Dentista newDentista = mapper.convertValue(dentistaDTO, Dentista.class);
        dentistaRepository.save(newDentista);
    }


    @Override
    public void addDentista(DentistaDTO dentistaDTO) {
        saveDentista(dentistaDTO);
    }

    @Override
    public DentistaDTO listDentista(Long id) throws Exception {
        Optional<Dentista> found = dentistaRepository.findById(id);
        if (found.isPresent()){
            return mapper.convertValue(found, DentistaDTO.class);
        } else {
            throw new Exception("No se encuentra el dentista");
        }
    }

    @Override
    public void modifyDentista(DentistaDTO dentistaDTO) {
       saveDentista(dentistaDTO);
    }

    @Override
    public void deleteDentista(Long id) {

        dentistaRepository.deleteById(id);
    }

    @Override
    public Collection<DentistaDTO> getAll() {
        List<Dentista> allDentista = dentistaRepository.findAll();
        Set<DentistaDTO> allDentistaDTO = new HashSet<DentistaDTO>();
        for(Dentista dentista: allDentista)
            allDentistaDTO.add(mapper.convertValue(dentista, DentistaDTO.class));

        return allDentistaDTO;
    }

    @Override
    public Set<DentistaDTO> getDentista(String name, String lastname) {
        Set<Dentista> allDentista = dentistaRepository.getDentista(name, lastname);
        Set<DentistaDTO> allDentistaDTO = new HashSet<DentistaDTO>();
        for (Dentista dentista: allDentista){
            allDentistaDTO.add(mapper.convertValue(dentista, DentistaDTO.class));
        }
        return allDentistaDTO;
    }
}
