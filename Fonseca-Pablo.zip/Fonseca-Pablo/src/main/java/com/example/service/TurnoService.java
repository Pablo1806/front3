package com.example.service;

import com.example.model.TurnoDTO;

import java.util.Collection;
import java.util.Set;

public interface TurnoService {
    void addTurno(TurnoDTO turnoDTO);
    TurnoDTO listTurno(Long id) throws Exception;
    void modifyTurno(TurnoDTO turnoDTO);
    void deleteTurno(Long id);

    Collection<TurnoDTO> getAll();
    Set<TurnoDTO> getTurno(Long id);
}
