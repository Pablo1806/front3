package com.example.service;



import com.example.model.PacienteDTO;

import java.util.Collection;
import java.util.Set;

public interface PacienteService {
    void addPaciente(PacienteDTO patientDTO);
    PacienteDTO listPaciente(Long id) throws Exception;
    void modifyPaciente(PacienteDTO pacienteDTO);
    void deletePaciente(Long id);

    Collection<PacienteDTO> getAll();
    Set<PacienteDTO> getPaciente(String name, String lastname, int dni);
}
