package com.example.service;

import com.example.model.DomicilioDTO;


import java.util.Collection;
import java.util.Set;


public interface DomicilioService {

    void addDomicilio(DomicilioDTO domicilioDTO);
    DomicilioDTO listDomicilio(Long id) throws Exception;
    void modifyDomicilio(DomicilioDTO domicilioDTO);
    void deleteDomicilio(Long id);

    Collection<DomicilioDTO> getAll();
    Set<DomicilioDTO> getDomicilio(String street, String number, String locality, String province);
}
