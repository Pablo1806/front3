package com.example.service;


import com.example.model.DentistaDTO;


import java.util.Collection;
import java.util.Set;

public interface DentistaService {
    void addDentista(DentistaDTO dentistaDTO);
    DentistaDTO listDentista(Long id) throws Exception;
    void modifyDentista(DentistaDTO dentistaDTO);
    void deleteDentista(Long id);

    Collection<DentistaDTO> getAll();
    Set<DentistaDTO> getDentista(String name, String lastname);
}
