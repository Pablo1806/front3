package com.example.service.impl;



import com.example.model.Paciente;
import com.example.model.PacienteDTO;
import com.example.repository.IPacienteRepository;
import com.example.service.PacienteService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PacienteServiceImpl implements PacienteService {

    @Autowired
    IPacienteRepository pacienteRepository;

    @Autowired
    ObjectMapper mapper;

    private void savePaciente(PacienteDTO pacienteDTO){
        Paciente newPaciente = mapper.convertValue(pacienteDTO, Paciente.class);
        pacienteRepository.save(newPaciente);
    }


    @Override
    public void addPaciente(PacienteDTO pacienteDTO) {
        savePaciente(pacienteDTO);
    }

    @Override
    public PacienteDTO listPaciente(Long id) throws Exception {
        Optional<Paciente> found = pacienteRepository.findById(id);
        if (found.isPresent())
            return mapper.convertValue(found, PacienteDTO.class);
        else
            throw new Exception("No se pudo encontrar al paciente");
    }

    @Override
    public void modifyPaciente(PacienteDTO pacienteDTO) {
      savePaciente(pacienteDTO);
    }

    @Override
    public void deletePaciente(Long id) {
    pacienteRepository.deleteById(id);
    }

    @Override
    public Collection<PacienteDTO> getAll() {
        List<Paciente> allPaciente = pacienteRepository.findAll();
        Set<PacienteDTO> allPacienteDTO = new HashSet<PacienteDTO>();
        for (Paciente paciente: allPaciente)
            allPacienteDTO.add(mapper.convertValue(paciente, PacienteDTO.class));

            return allPacienteDTO;
    }

    @Override
    public Set<PacienteDTO> getPaciente(String name, String lastname, int dni) {
        Set<Paciente> allPaciente = pacienteRepository.getPaciente(name, lastname, dni);
        Set<PacienteDTO> allPacienteDTO = new HashSet<PacienteDTO>();
        for (Paciente paciente: allPaciente)
            allPacienteDTO.add(mapper.convertValue(paciente, PacienteDTO.class));

        return allPacienteDTO;
    }
}
