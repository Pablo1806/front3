package com.example.service.impl;

import com.example.model.Domicilio;
import com.example.model.DomicilioDTO;

import com.example.repository.IDomicilioRepository;

import com.example.service.DomicilioService;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DomicilioServiceImpl implements DomicilioService {

    @Autowired
    IDomicilioRepository domicilioRepository;

    @Autowired
    ObjectMapper mapper;

    private void saveDomicilio(DomicilioDTO domicilioDTO){
        Domicilio newDomicilio = mapper.convertValue(domicilioDTO, Domicilio.class);
        domicilioRepository.save(newDomicilio);
    }

    @Override
    public void addDomicilio(DomicilioDTO domicilioDTO) {
        saveDomicilio(domicilioDTO);
    }

    @Override
    public DomicilioDTO listDomicilio(Long id) throws Exception {
        Optional<Domicilio> found = domicilioRepository.findById(id);
        if (found.isPresent()){
            return mapper.convertValue(found, DomicilioDTO.class);
        } else {
            throw new Exception("No se encuentra el domicilio");
        }
    }

    @Override
    public void modifyDomicilio(DomicilioDTO domicilioDTO) {
     saveDomicilio(domicilioDTO);
    }

    @Override
    public void deleteDomicilio(Long id) {
    domicilioRepository.deleteById(id);
    }

    @Override
    public Collection<DomicilioDTO> getAll() {
        List<Domicilio> allDomicilio = domicilioRepository.findAll();
        Set<DomicilioDTO> allDomicilioDTO = new HashSet<DomicilioDTO>();
        for (Domicilio domicilio:allDomicilio)
            allDomicilioDTO.add(mapper.convertValue(domicilio, DomicilioDTO.class));

        return allDomicilioDTO;
    }

    @Override
    public Set<DomicilioDTO> getDomicilio(String street, String number, String locality, String province) {
        Set<Domicilio> allDomicilio = domicilioRepository.getDomicilio(street, number, locality, province);
        Set<DomicilioDTO> allDomicilioDTO = new HashSet<DomicilioDTO>();
        for (Domicilio domicilio: allDomicilio)
            allDomicilioDTO.add(mapper.convertValue(domicilio, DomicilioDTO.class));

        return allDomicilioDTO;
    }
}
