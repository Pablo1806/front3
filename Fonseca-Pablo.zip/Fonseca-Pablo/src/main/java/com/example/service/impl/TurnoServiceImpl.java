package com.example.service.impl;


import com.example.model.Turno;
import com.example.model.TurnoDTO;

import com.example.repository.ITurnoRepository;

import com.example.service.TurnoService;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TurnoServiceImpl implements TurnoService {

    @Autowired
    ITurnoRepository turnoRepository;

    @Autowired
    ObjectMapper mapper;

    private void saveTurno(TurnoDTO turnoDTO){
        Turno newTurno = mapper.convertValue(turnoDTO, Turno.class);
        turnoRepository.save(newTurno);
    }


    @Override
    public void addTurno(TurnoDTO turnoDTO) {
        saveTurno(turnoDTO);
    }

    @Override
    public TurnoDTO listTurno(Long id) throws Exception {
        Optional<Turno> found = turnoRepository.findById(id);
        if (found.isPresent())
            return mapper.convertValue(found, TurnoDTO.class);
        else
            throw new Exception("No se encuentra el turno");
    }

    @Override
    public void modifyTurno(TurnoDTO turnoDTO) {
       saveTurno(turnoDTO);
    }

    @Override
    public void deleteTurno(Long id) {
      turnoRepository.deleteById(id);
    }

    @Override
    public Collection<TurnoDTO> getAll() {
        List<Turno> allTurno = turnoRepository.findAll();
        Set <TurnoDTO> allTurnoDTO = new HashSet<TurnoDTO>();
        for (Turno turno: allTurno)
            allTurnoDTO.add(mapper.convertValue(turno, TurnoDTO.class));
        return allTurnoDTO;
    }

    @Override
    public Set<TurnoDTO> getTurno(Long id) {
        Set<Turno> allTurno = turnoRepository.getTurno(id);
        Set<TurnoDTO> allTurnoDTO = new HashSet<TurnoDTO>();
        for (Turno turno: allTurno)
            allTurnoDTO.add(mapper.convertValue(turno, TurnoDTO.class));
        return allTurnoDTO;
    }
}
