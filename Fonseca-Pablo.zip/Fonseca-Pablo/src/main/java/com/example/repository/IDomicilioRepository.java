package com.example.repository;

import com.example.model.Domicilio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface IDomicilioRepository extends JpaRepository<Domicilio, Long> {

    @Query("from Domicilio d where d.street like %:street%, d.number like %:number%, d.locality like %:locality%, d.province like %:province%")
    Set<Domicilio> getDomicilio(@Param("street") String street, @Param("number") String number, @Param("locality") String locality, @Param("province") String province);

}
