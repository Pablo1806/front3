package com.example.repository;

import com.example.model.Turno;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface ITurnoRepository extends JpaRepository<Turno, Long> {
    @Query("from Turno s where s.id")
    Set<Turno> getTurno(@Param("id") Long id);
}
