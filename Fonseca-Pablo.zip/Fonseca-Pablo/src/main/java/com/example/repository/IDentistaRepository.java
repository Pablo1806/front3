package com.example.repository;

import com.example.model.Dentista;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface IDentistaRepository extends JpaRepository<Dentista, Long> {
    @Query("from Dentista de where de.name like %:name%, de.lastname like %:lastname%")
    Set<Dentista> getDentista(@Param("name") String name, @Param("lastname") String lastname);
}
