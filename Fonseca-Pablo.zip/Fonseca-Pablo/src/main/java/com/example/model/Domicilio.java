package com.example.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;


import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "Domicilio")
@Getter
@Setter
public class Domicilio {
    @Id
    @GeneratedValue
    private Long id;


    private String street;
    private String number;
    private String locality;
    private String province;

    @OneToOne(mappedBy = "domicilio")
    @JsonIgnore
    private Set<Paciente> paciente;

    public Domicilio() {

    }

    public Domicilio(String street, String number, String locality, String province) {
        this.street = street;
        this.number = number;
        this.locality = locality;
        this.province = province;
    }

    public Domicilio(Long id, String street, String number, String locality, String province) {
        this.id = id;
        this.street = street;
        this.number = number;
        this.locality = locality;
        this.province = province;
    }

    @Override
    public String toString() {
        return "Domicilio{" +
                "id=" + id +
                ", street='" + street + '\'' +
                ", number='" + number + '\'' +
                ", locality='" + locality + '\'' +
                ", province='" + province + '\'' +
                ", paciente=" + paciente +
                '}';
    }
}
