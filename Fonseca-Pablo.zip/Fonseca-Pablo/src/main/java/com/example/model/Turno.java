package com.example.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "Turno")
@Getter
@Setter
public class Turno {

        @Id
        @GeneratedValue
        private Long id;

        private Paciente paciente;
        private Dentista dentista;
        private Date dischargeDate;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
           name = "TurnoUsers",
            joinColumns = @JoinColumn(name = "id_paciente"),
           inverseJoinColumns = @JoinColumn(name = "id_dentista")
    )

    private Set<Turno> turno;

    public Turno() {
    }

    public Turno(Paciente paciente, Dentista dentista, Date dischargeDate) {
        this.paciente = paciente;
        this.dentista = dentista;
        this.dischargeDate = dischargeDate;
    }

    public Turno(Long id, Paciente paciente, Dentista dentista, Date dischargeDate) {
        this.id = id;
        this.paciente = paciente;
        this.dentista = dentista;
        this.dischargeDate = dischargeDate;
    }

    @Override
    public String toString() {
        return "Turno{" +
                "id=" + id +
                ", paciente=" + paciente +
                ", dentista=" + dentista +
                ", dischargeDate=" + dischargeDate +
                ", turno=" + turno +
                '}';
    }
}
