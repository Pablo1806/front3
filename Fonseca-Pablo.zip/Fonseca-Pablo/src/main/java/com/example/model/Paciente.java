package com.example.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "Paciente")
@Getter
@Setter

public class Paciente {

    @Id
    @GeneratedValue
    private Long id;


    private String name;
    private String lastname;
    @ManyToOne
    @JoinColumn(name = "domicilio_id")
    private Domicilio domicilio;
    private int dni;
    private Date dischargeDate;

    @OneToMany(mappedBy = "paciente")
    @JsonIgnore
    private Set<Dentista> dentista;

    public Paciente() {
    }

    public Paciente(String name, String lastname, Domicilio domicilio, int dni, Date dischargeDate) {
        this.name = name;
        this.lastname = lastname;
        this.domicilio = domicilio;
        this.dni = dni;
        this.dischargeDate = dischargeDate;
    }

    public Paciente(Long id, String name, String lastname, Domicilio domicilio, int dni, Date dischargeDate) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.domicilio = domicilio;
        this.dni = dni;
        this.dischargeDate = dischargeDate;
    }


    @Override
    public String toString() {
        return "Paciente{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", lastname='" + lastname + '\'' +
                ", domicilio=" + domicilio +
                ", dni=" + dni +
                ", dischargeDate=" + dischargeDate +
                ", dentista=" + dentista +
                '}';
    }
}
