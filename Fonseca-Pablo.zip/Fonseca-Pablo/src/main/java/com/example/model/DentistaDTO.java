package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DentistaDTO {
    private Long id;
    private String name;
    private String lastname;
    private Integer enrollment;
}
