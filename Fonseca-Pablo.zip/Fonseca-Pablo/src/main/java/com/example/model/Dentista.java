package com.example.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;


import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name ="Dentista")
@Getter
@Setter
public class Dentista {
    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String lastname;
    private Integer enrollment;

     @OneToMany(mappedBy = "dentista")
     @JsonIgnore
     private Set<Paciente> paciente;

    public Dentista(String name, String lastname, Integer enrollment) {
        this.name = name;
        this.lastname = lastname;
        this.enrollment = enrollment;
    }

    public Dentista(Long id, String name, String lastname, Integer enrollment) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.enrollment = enrollment;
    }

    @Override
    public String toString() {
        return "Dentista{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", lastname='" + lastname + '\'' +
                ", dni=" + enrollment +
                '}';
    }
}
