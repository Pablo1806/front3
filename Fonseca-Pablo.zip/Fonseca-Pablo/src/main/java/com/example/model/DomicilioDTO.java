package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DomicilioDTO {
    private Long id;


    private String street;
    private String number;
    private String locality;
    private String province;
}
