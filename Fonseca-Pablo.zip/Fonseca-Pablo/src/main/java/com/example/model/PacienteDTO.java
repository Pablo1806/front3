package com.example.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class PacienteDTO {
    private Long id;
    private String name;
    private String lastname;
    private Domicilio domicilio;
    private int dni;
    private Date dischargeDate;
}
