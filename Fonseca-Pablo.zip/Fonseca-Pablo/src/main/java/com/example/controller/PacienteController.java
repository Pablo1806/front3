package com.example.controller;

import com.example.model.PacienteDTO;

import com.example.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.Set;

@RestController
@RequestMapping("/paciente")
public class PacienteController {

    @Autowired
    PacienteService pacienteService;


    @PostMapping()
    public ResponseEntity<?> addPaciente(@RequestBody PacienteDTO pacienteDTO){
        pacienteService.addPaciente(pacienteDTO);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public PacienteDTO readPaciente(@PathVariable Long id) throws  Exception {
        return pacienteService.listPaciente(id);
    }

    @PutMapping()
    public ResponseEntity<?> modifyPaciente(@RequestBody PacienteDTO pacienteDTO){
        pacienteService.modifyPaciente(pacienteDTO);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePaciente(@PathVariable Long id){
        ResponseEntity<String> response = null;
        pacienteService.deletePaciente(id);
        response = ResponseEntity.status(HttpStatus.OK).body("Eliminado");
        return response;
    }

    @GetMapping("/list")
    public Collection<PacienteDTO> listPaciente(){
        return pacienteService.getAll();
    }

    @GetMapping("/getNameLastname")
        public Set<PacienteDTO> getNameLastname(@RequestParam String name, @RequestParam String lastname, @RequestParam int dni){
            return pacienteService.getPaciente(name, lastname, dni);
        }

}
