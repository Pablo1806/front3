package com.example.controller;


import com.example.model.DentistaDTO;
import com.example.service.DentistaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.Set;

@RestController
@RequestMapping("/dentista")
public class DentistaController {

    @Autowired
    DentistaService dentistaService;


    @PostMapping()
    public ResponseEntity<?> addDentista(@RequestBody DentistaDTO dentistaDTO){
        dentistaService.addDentista(dentistaDTO);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public DentistaDTO readDentista(@PathVariable Long id) throws  Exception {
        return dentistaService.listDentista(id);
    }

    @PutMapping()
    public ResponseEntity<?> modifyDentista(@RequestBody DentistaDTO dentistaDTO){
        dentistaService.modifyDentista(dentistaDTO);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDentista(@PathVariable Long id){
        ResponseEntity<String> response = null;
        dentistaService.deleteDentista(id);
        response = ResponseEntity.status(HttpStatus.OK).body("Eliminado");
        return response;
    }

    @GetMapping("/list")
    public Collection<DentistaDTO> listDentista(){
        return dentistaService.getAll();
    }

    @GetMapping("/getNameLastname")
        public Set<DentistaDTO> getByNameAndLastName(@RequestParam String name, @RequestParam String lastname){
            return dentistaService.getDentista(name, lastname);
        }


}
