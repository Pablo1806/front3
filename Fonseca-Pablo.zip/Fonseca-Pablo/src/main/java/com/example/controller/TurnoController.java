package com.example.controller;


import com.example.model.TurnoDTO;
import com.example.service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.Set;

@RestController
@RequestMapping("turno")
public class TurnoController {

    @Autowired
    TurnoService turnoService;


    @PostMapping()
    public ResponseEntity<?> addTurno(@RequestBody TurnoDTO turnoDTO){
        turnoService.addTurno(turnoDTO);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public TurnoDTO readTurno(@PathVariable Long id) throws  Exception {
        return turnoService.listTurno(id);
    }

    @PutMapping()
    public ResponseEntity<?> modifyTurno(@RequestBody TurnoDTO turnoDTO){
        turnoService.modifyTurno(turnoDTO);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTurno(@PathVariable Long id){
        ResponseEntity<String> response = null;
        turnoService.deleteTurno(id);
        response = ResponseEntity.status(HttpStatus.OK).body("Turno eliminado");
        return response;
    }

    @GetMapping("/list")
    public Collection<TurnoDTO> listPaciente(){
        return turnoService.getAll();
    }

    @GetMapping("/getTurnoById")
        public Set<TurnoDTO> getTurno(@RequestParam Long id){
            return turnoService.getTurno(id);

    }
}
